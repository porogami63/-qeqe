//The Prescription class represents a prescription with fields for prescription ID, patient name, medication, dosage, 
//issue date, administered by timeframe start, and timeframe end, and includes getters and setters for these fields.
//It also manages a queue of prescriptions, providing methods to add to, remove from,and inspect the queue
// and includes a method to remove elements from the queue based on the timeframe.



package src;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Prescription {
    private int prescriptionId;
    private String patientName;
    private String medication;
    private String dosage;
    private String issueDate;
    private String administeredBy;
    private String timeframeStart;
    private String timeframeEnd;

    public Prescription(int prescriptionId, String patientName, String medication, String dosage, String issueDate, String administeredBy, String timeframeStart, String timeframeEnd) {
        this.prescriptionId = prescriptionId;
        this.patientName = patientName;
        this.medication = medication;
        this.dosage = dosage;
        this.issueDate = issueDate;
        this.administeredBy = administeredBy;
        this.timeframeStart = timeframeStart;
        this.timeframeEnd = timeframeEnd;
    }

    public int getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(int prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getMedication() {
        return medication;
    }

    public void setMedication(String medication) {
        this.medication = medication;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getAdministeredBy() {
        return administeredBy;
    }

    public void setAdministeredBy(String administeredBy) {
        this.administeredBy = administeredBy;
    }

    public String getTimeframeStart() {
        return timeframeStart;
    }

    public void setTimeframeStart(String timeframeStart) {
        this.timeframeStart = timeframeStart;
    }

    public String getTimeframeEnd() {
        return timeframeEnd;
    }

    public void setTimeframeEnd(String timeframeEnd) {
        this.timeframeEnd = timeframeEnd;
    }

    static Queue<String[][]> prescriptionQueue = new LinkedList<>();

    public static void addToQueue(String[][] prescriptionData) {
        prescriptionQueue.add(prescriptionData);
    }

    public static String[][] removeFromQueue() {
        return prescriptionQueue.poll();
    }

    public static boolean isQueueEmpty() {
        return prescriptionQueue.isEmpty();
    }

    public static void printQueue() {
        for (String[][] data : prescriptionQueue) {
            System.out.println(Arrays.deepToString(data));
        }
    }

    public static void removeElementsBasedOnTimeframe() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        Queue<String[][]> queue = prescriptionQueue;
        queue.removeIf(data -> {
            try {
                Date date = sdf.parse(data[0][4]);
                return false;
            } catch (ParseException e) {
                System.err.println("Unparseable date: " + data[0][4]);
                return true; 
            }
        });
    }
}